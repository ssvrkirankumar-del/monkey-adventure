﻿// 리깅 웨이트 오버레이 컬러 모드. 0 = Low/High 그라데이션, 1 = 무지개 colormap (기본)
float _UMXWeightColorMode;
float4 _UMXWeightLowColor;
float4 _UMXWeightHighColor;

float4 Temperature(float4 color, float weight)
{
    float softSelect = step(-0.01f, weight);

    // 무지개 colormap (mode 1)
    // 0 1,0,0 -> 0.5,0.5,0 -> 0, 1, 0 -> 0, 0.5, 0.5 -> 0,0,1
    float t = (1 - weight) * 2;
    float4 rainbow = float4(saturate(float3(1.5f - t, 1.0f - abs(t - 1), 1.5f - abs(t - 2))), color.w);

    // Low/High 그라데이션 (mode 0). authored RGBA 그대로 보간
    float4 gradient = lerp(_UMXWeightLowColor, _UMXWeightHighColor, saturate(weight));

    // _UMXWeightColorMode 는 0 또는 1 만 들어오므로 분기 없이 선택
    float4 selected = lerp(gradient, rainbow, _UMXWeightColorMode);
    return color * (1 - softSelect) + softSelect * selected;
}

float4 UVToPos(float2 uvPos)
{
    float4 worldPos = float4(uvPos, 1, 1);
    worldPos = mul(UNITY_MATRIX_VP, worldPos);
    return float4(worldPos.xy, 0.5, 1);
}

